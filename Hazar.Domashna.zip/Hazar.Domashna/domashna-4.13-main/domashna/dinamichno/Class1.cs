﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dinamichno
{
    
        public class DynamicList
        {
            private class Node
            {
                public object Element;
                public Node Next;

                public Node(object element)
                {
                    Element = element;
                    Next = null;
                }
            }

            private Node head;
            private Node tail;
            private int count;

            public DynamicList()
            {
                head = null;
                tail = null;
                count = 0;
            }

            public int Count
            {
                get { return count; }
            }

            public void Add(object item)
            {
                Node newNode = new Node(item);

                if (head == null)
                {
                    head = tail = newNode;
                }
                else
                {
                    tail.Next = newNode;
                    tail = newNode;
                }

                count++;
            }

            private Node GetNode(int index)
            {
                if (index < 0 || index >= count)
                    throw new IndexOutOfRangeException();

                Node current = head;
                for (int i = 0; i < index; i++)
                {
                    current = current.Next;
                }
                return current;
            }

            public object Remove(int index)
            {
                if (index < 0 || index >= count)
                    throw new IndexOutOfRangeException();

                Node removed;

                if (index == 0)
                {
                    removed = head;
                    head = head.Next;
                }
                else
                {
                    Node prev = GetNode(index - 1);
                    removed = prev.Next;
                    prev.Next = removed.Next;

                    if (removed == tail)
                        tail = prev;
                }

                count--;
                return removed.Element;
            }

            public int Remove(object item)
            {
                Node current = head;
                Node prev = null;
                int index = 0;

                while (current != null)
                {
                    if (current.Element.Equals(item))
                    {
                        if (prev == null)
                            head = current.Next;
                        else
                            prev.Next = current.Next;

                        if (current == tail)
                            tail = prev;

                        count--;
                        return index;
                    }

                    prev = current;
                    current = current.Next;
                    index++;
                }

                return -1;
            }

            public int IndexOf(object item)
            {
                Node current = head;
                int index = 0;

                while (current != null)
                {
                    if (current.Element.Equals(item))
                        return index;

                    current = current.Next;
                    index++;
                }

                return -1;
            }

            public bool Contains(object item)
            {
                return IndexOf(item) != -1;
            }

            public object this[int index]
            {
                get
                {
                    return GetNode(index).Element;
                }
            }
        }
    }

